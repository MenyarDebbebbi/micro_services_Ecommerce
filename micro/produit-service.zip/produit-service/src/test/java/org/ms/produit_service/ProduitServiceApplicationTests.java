package org.ms.produit_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProduitServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
