package org.ms.reglement_service.entities;

import lombok.Data;

@Data
public class Client {
    private Long id;
    private String nom;
    private String email;
    // autres attributs nécessaires
} 