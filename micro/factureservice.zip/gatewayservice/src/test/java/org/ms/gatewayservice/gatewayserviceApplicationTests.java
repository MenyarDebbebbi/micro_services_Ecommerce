package org.ms.gatewayservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class gatewayserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
