package org.ms.authentificationservice.dto;

import lombok.Data;

@Data
public class UserRoleData {
    private String username;
    private String roleName;
}
