package org.ms.authentificationservice.services;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.ms.authentificationservice.entities.AppRole;
import org.ms.authentificationservice.entities.AppUser;
import org.ms.authentificationservice.repositories.AppRoleRepository;
import org.ms.authentificationservice.repositories.AppUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
	private  AppUserRepository userRepository;
    @Autowired
    private  AppRoleRepository roleRepository;
    //déclaration d’un attribut
    private PasswordEncoder passwordEncoder=null;

    @Override
    public AppUser addUser(AppUser appUser) {
    	 appUser.setPassword(passwordEncoder.encode(appUser.getPassword()));
        return userRepository.save(appUser);
    }

    @Override
    public AppRole addRole(AppRole appRole) {
        return roleRepository.save(appRole);
    }

    @Override
    public void addRoleToUser(String username, String roleName) {
        AppUser user = userRepository.findByUsername(username);
        AppRole role = roleRepository.findByRoleName(roleName);
        if (user != null && role != null) {
            user.getRoles().add(role);
            userRepository.save(user); // facultatif grâce à @Transactional
        }
    }

    @Override
    public AppUser getUserByName(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    public List<AppUser> getAllUsers() {
        return userRepository.findAll();
    }

    //Injection de dépendance par constructeur
    public UserServiceImpl(PasswordEncoder passwordEncoder)
    {
    this.passwordEncoder=passwordEncoder;
	
    }

}
