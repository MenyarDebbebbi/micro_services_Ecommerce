package org.ms.authentificationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthentificationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
