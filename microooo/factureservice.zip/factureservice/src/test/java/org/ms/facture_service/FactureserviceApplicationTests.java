package org.ms.facture_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FactureserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
